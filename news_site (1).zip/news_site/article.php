<?php
require_once __DIR__ . '/inc/functions.php';
require_once __DIR__ . '/templates/header.php';
$slug = $_GET['slug'] ?? null;
if (!$slug) { echo '<p>Article not found</p>'; require_once __DIR__ . '/templates/footer.php'; exit; }
$article = getArticleBySlug($slug);
if (!$article) { echo '<p>Article not found</p>'; require_once __DIR__ . '/templates/footer.php'; exit; }
$pdo->prepare('UPDATE articles SET views = views + 1 WHERE id = ?')->execute([$article['id']]);
?>
<article class="single">
  <h1><?= e($article['title']) ?></h1>
  <p class="meta">By <?= e($article['author_name']) ?> — <?= date('F j, Y', strtotime($article['publish_at'] ?? $article['created_at'])) ?></p>
  <?php if ($article['featured_image']): ?>
    <img src="<?= UPLOAD_WEB . '/' . e($article['featured_image']) ?>" alt="<?= e($article['title']) ?>">
  <?php endif; ?>
  <div class="content"><?= $article['content'] ?></div>

  <section class="comments">
    <h3>Comments</h3>
    <form id="comment-form">
      <input name="name" placeholder="Name">
      <input name="email" placeholder="Email">
      <textarea name="body" placeholder="Write a comment"></textarea>
      <input type="hidden" name="article_id" value="<?= e($article['id']) ?>">
      <button type="submit">Post comment</button>
    </form>
    <div id="comment-feedback"></div>
  </section>
</article>

<script>
document.getElementById('comment-form').addEventListener('submit', function(e){
  e.preventDefault();
  var fd = new FormData(this);
  fetch('/api/comments.php',{method:'POST',body:fd}).then(r=>r.json()).then(data=>{ document.getElementById('comment-feedback').innerText = 'Comment submitted — awaiting moderation'; this.reset(); });
});
</script>

<?php require_once __DIR__ . '/templates/footer.php'; ?>