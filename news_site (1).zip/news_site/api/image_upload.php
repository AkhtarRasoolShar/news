<?php
require_once __DIR__ . '/../inc/config.php';
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo json_encode(['error'=>'invalid']); exit; }
if (empty($_FILES['file'])) { echo json_encode(['error'=>'nofile']); exit; }

$file = $_FILES['file'];
$allowed = ['image/jpeg','image/png','image/webp'];
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);
if (!in_array($mime, $allowed)) { echo json_encode(['error'=>'invalid_type']); exit; }
if ($file['size'] > 4 * 1024 * 1024) { echo json_encode(['error'=>'too_large']); exit; }

$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
$filename = bin2hex(random_bytes(8)) . '.' . $ext;
if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);
$dest = UPLOAD_DIR . '/' . $filename;
if (!move_uploaded_file($file['tmp_name'], $dest)) { echo json_encode(['error'=>'move_failed']); exit; }

echo json_encode(['url' => UPLOAD_WEB . '/' . $filename]);