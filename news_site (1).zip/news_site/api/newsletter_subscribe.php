<?php
require_once __DIR__ . '/../inc/db.php';
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['token'])) {
    $token = $_GET['token'];
    $stmt = $pdo->prepare('UPDATE subscribers SET verified = 1 WHERE token = ?');
    $stmt->execute([$token]);
    echo 'Thank you — subscription confirmed.'; exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
    if (!$email) { http_response_code(400); echo 'Invalid email'; exit; }
    $token = bin2hex(random_bytes(32));
    $stmt = $pdo->prepare('INSERT INTO subscribers (email, token) VALUES (?, ?) ON DUPLICATE KEY UPDATE token = VALUES(token), verified = 0');
    $stmt->execute([$email, $token]);
    $link = BASE_URL . '/api/newsletter_subscribe.php?token=' . $token;
    mail($email, 'Confirm subscription', "Click to confirm: $link", 'From: no-reply@example.com');
    echo 'ok';
}