<?php
require_once __DIR__ . '/../inc/db.php';
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $article_id = (int)($_POST['article_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
    $body = trim($_POST['body'] ?? '');
    if (!$article_id || !$body) { http_response_code(400); echo json_encode(['error'=>'invalid']); exit; }
    $stmt = $pdo->prepare('INSERT INTO comments (article_id, name, email, body, status) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$article_id, $name, $email, $body, 'pending']);
    echo json_encode(['ok'=>true]); exit;
}

http_response_code(405); echo json_encode(['error'=>'method']);