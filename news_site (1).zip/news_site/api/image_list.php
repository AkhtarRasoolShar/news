<?php
require_once __DIR__ . '/../inc/config.php';
header('Content-Type: application/json');
$dir = UPLOAD_DIR;
$files = [];
if (is_dir($dir)) {
    $it = new DirectoryIterator($dir);
    foreach ($it as $f) {
        if ($f->isFile()) {
            $name = $f->getFilename();
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg','jpeg','png','webp'])) {
                $files[] = ['name'=>$name,'url'=>UPLOAD_WEB . '/' . $name,'size'=>$f->getSize(),'mtime'=>$f->getMTime()];
            }
        }
    }
}
echo json_encode($files);