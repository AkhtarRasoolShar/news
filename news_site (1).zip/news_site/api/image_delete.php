<?php
require_once __DIR__ . '/../inc/config.php';
require_once __DIR__ . '/../inc/auth.php';
require_once __DIR__ . '/../inc/db.php';
header('Content-Type: application/json');
session_start();
if (empty($_SESSION['user_id'])) { http_response_code(401); echo json_encode(['error'=>'login']); exit; }
if (!in_array($_SESSION['role'], ['admin','editor'])) { http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }

$name = basename($_POST['name'] ?? '');
if (!$name) { http_response_code(400); echo json_encode(['error'=>'invalid']); exit; }
$path = realpath(UPLOAD_DIR . '/' . $name);
$uploadsReal = realpath(UPLOAD_DIR);
if (!$path || strpos($path, $uploadsReal) !== 0) { http_response_code(400); echo json_encode(['error'=>'badpath']); exit; }
if (is_file($path)) { unlink($path); echo json_encode(['ok'=>true]); exit; }
http_response_code(404); echo json_encode(['error'=>'notfound']);