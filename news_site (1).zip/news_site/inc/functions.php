<?php
require_once __DIR__ . '/db.php';

function getCategories() {
    global $pdo; return $pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();
}

function getArticles($page = 1, $perPage = 9) {
    global $pdo;
    $offset = ($page - 1) * $perPage;
    $stmt = $pdo->prepare('SELECT a.*, u.display_name as author_name, c.name as category_name FROM articles a JOIN users u ON a.author_id = u.id LEFT JOIN categories c ON a.category_id = c.id WHERE a.status = "published" AND (a.publish_at IS NULL OR a.publish_at <= NOW()) ORDER BY a.publish_at DESC LIMIT :off, :lim');
    $stmt->bindValue(':off', $offset, PDO::PARAM_INT);
    $stmt->bindValue(':lim', $perPage, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function getArticleBySlug($slug) {
    global $pdo;
    $stmt = $pdo->prepare('SELECT a.*, u.display_name as author_name, c.name as category_name FROM articles a JOIN users u ON a.author_id = u.id LEFT JOIN categories c ON a.category_id = c.id WHERE a.slug = ? AND a.status = "published" AND (a.publish_at IS NULL OR a.publish_at <= NOW()) LIMIT 1');
    $stmt->execute([$slug]);
    return $stmt->fetch();
}

function excerpt($html, $len = 200) {
    $text = strip_tags($html);
    if (strlen($text) <= $len) return $text;
    return substr($text, 0, $len) . '...';
}

function create_slug($title) {
    $slug = preg_replace('/[^A-Za-z0-9-]+/', '-', strtolower($title));
    return trim($slug, '-');
}

function handle_upload($file) {
    if (empty($file) || $file['error'] !== UPLOAD_ERR_OK) return null;
    $allowed = ['image/jpeg','image/png','image/webp'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    if (!in_array($mime, $allowed)) return null;
    if ($file['size'] > 3 * 1024 * 1024) return null;
    if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $name = bin2hex(random_bytes(8)) . '.' . $ext;
    $dest = UPLOAD_DIR . '/' . $name;
    if (!move_uploaded_file($file['tmp_name'], $dest)) return null;
    return $name;
}