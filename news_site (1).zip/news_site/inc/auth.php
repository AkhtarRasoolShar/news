<?php
session_start();
require_once __DIR__ . '/db.php';

function login($username, $password) {
    global $pdo;
    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ? LIMIT 1');
    $stmt->execute([$username]);
    $u = $stmt->fetch();
    if ($u && password_verify($password, $u['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $u['id'];
        $_SESSION['username'] = $u['username'];
        $_SESSION['role'] = $u['role'];
        return true;
    }
    return false;
}

function require_login() {
    if (empty($_SESSION['user_id'])) {
        header('Location: /admin/login.php'); exit;
    }
}

function require_role($roles = []) {
    if (empty($_SESSION['user_id'])) header('Location: /admin/login.php');
    if (!in_array($_SESSION['role'], (array)$roles)) {
        http_response_code(403); echo 'Forbidden'; exit;
    }
}

function logout() {
    session_unset(); session_destroy();
}