<?php
function send_mail($to, $subject, $message, $headers = []) {
    $hdrs = "From: no-reply@example.com\r\n" . implode("\r\n", $headers);
    return mail($to, $subject, $message, $hdrs);
}