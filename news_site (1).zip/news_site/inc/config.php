<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'news_site');
define('DB_USER', 'root');
define('DB_PASS', '');

define('BASE_URL', 'http://localhost:8000');

define('UPLOAD_DIR', __DIR__ . '/../assets/uploads');
define('UPLOAD_WEB', BASE_URL . '/assets/uploads');

ini_set('display_errors', 1);
error_reporting(E_ALL);

function e($s) { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }