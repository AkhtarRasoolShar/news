<?php
require_once __DIR__ . '/inc/functions.php';
require_once __DIR__ . '/templates/header.php';

$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$articles = getArticles($page, 9);
$categories = getCategories();
?>

<div class="hero">
  <h1>Latest News</h1>
</div>

<div class="grid">
  <?php foreach ($articles as $a): ?>
    <article class="card">
      <?php if ($a['featured_image']): ?>
        <img src="<?= UPLOAD_WEB . '/' . e($a['featured_image']) ?>" alt="<?= e($a['title']) ?>">
      <?php endif; ?>
      <h2><a href="<?= BASE_URL ?>/article.php?slug=<?= e($a['slug']) ?>"><?= e($a['title']) ?></a></h2>
      <p class="meta"><?= e($a['author_name']) ?> — <?= date('F j, Y', strtotime($a['publish_at'] ?? $a['created_at'])) ?></p>
      <p><?= e(excerpt($a['content'], 180)) ?></p>
    </article>
  <?php endforeach; ?>
</div>

<?php require_once __DIR__ . '/templates/footer.php'; ?>