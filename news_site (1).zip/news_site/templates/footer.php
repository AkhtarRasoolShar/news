</main>
<footer class="site-footer">
  <div class="container">&copy; <?= date('Y') ?> NewsSite</div>
</footer>
</body>
</html>