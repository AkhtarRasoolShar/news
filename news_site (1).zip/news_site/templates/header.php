<?php require_once __DIR__ . '/../inc/config.php'; ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>News Site</title>
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/styles.css">
</head>
<body>
<nav class="navbar">
  <div class="container">
    <a href="<?= BASE_URL ?>" class="brand">NewsSite</a>
    <form action="<?= BASE_URL ?>/search.php" method="get" class="search">
      <input name="q" placeholder="Search...">
    </form>
    <a href="<?= BASE_URL ?>/admin/login.php" class="btn">Admin</a>
  </div>
</nav>
<main class="container">