<?php
require_once __DIR__ . '/../../inc/auth.php';
require_login(); require_role(['admin']);
require_once __DIR__ . '/../../inc/db.php';
$id = (int)($_GET['id'] ?? 0);
if (!$id) header('Location: list.php');
$stmt = $pdo->prepare('SELECT id, username, email, role, display_name FROM users WHERE id = ?'); $stmt->execute([$id]); $user = $stmt->fetch();
if (!$user) header('Location: list.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $display = $_POST['display_name'] ?? '';
  $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
  $role = $_POST['role'];
  if (!empty($_POST['password'])) {
    $hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $pdo->prepare('UPDATE users SET display_name = ?, email = ?, role = ?, password_hash = ? WHERE id = ?')
      ->execute([$display, $email, $role, $hash, $id]);
  } else {
    $pdo->prepare('UPDATE users SET display_name = ?, email = ?, role = ? WHERE id = ?')
      ->execute([$display, $email, $role, $id]);
  }
  header('Location: list.php'); exit;
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Edit User</title><link rel="stylesheet" href="/assets/css/styles.css"></head><body>
<div class="admin-wrap">
  <h1>Edit User: <?= e($user['username']) ?></h1>
  <form method="post">
    <input name="display_name" value="<?= e($user['display_name']) ?>">
    <input name="email" value="<?= e($user['email']) ?>" required>
    <input name="password" type="password" placeholder="Leave empty to keep current">
    <select name="role">
      <option value="admin" <?= $user['role']=='admin'?'selected':'' ?>>Admin</option>
      <option value="editor" <?= $user['role']=='editor'?'selected':'' ?>>Editor</option>
      <option value="author" <?= $user['role']=='author'?'selected':'' ?>>Author</option>
    </select>
    <button>Save</button>
  </form>
</div>
</body></html>