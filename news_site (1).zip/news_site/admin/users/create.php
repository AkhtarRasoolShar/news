<?php
require_once __DIR__ . '/../../inc/auth.php';
require_login(); require_role(['admin']);
require_once __DIR__ . '/../../inc/db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = trim($_POST['username']);
  $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
  $password = $_POST['password'];
  $role = $_POST['role'];
  if (!$username || !$email || !$password) $error = 'Missing fields';
  else {
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO users (username, email, password_hash, role, display_name) VALUES (?,?,?,?,?)');
    $stmt->execute([$username,$email,$hash,$role,$_POST['display_name']]);
    header('Location: list.php'); exit;
  }
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Create User</title><link rel="stylesheet" href="/assets/css/styles.css"></head><body>
<div class="admin-wrap">
  <h1>Create User</h1>
  <?php if (!empty($error)): ?><div class="error"><?= e($error) ?></div><?php endif; ?>
  <form method="post">
    <input name="username" placeholder="username" required>
    <input name="display_name" placeholder="Display name">
    <input name="email" placeholder="email" required>
    <input name="password" type="password" placeholder="password" required>
    <select name="role">
      <option value="admin">Admin</option>
      <option value="editor">Editor</option>
      <option value="author">Author</option>
    </select>
    <button>Create</button>
  </form>
</div>
</body></html>