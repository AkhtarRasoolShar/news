<?php
require_once __DIR__ . '/../inc/auth.php'; require_login();
require_once __DIR__ . '/../inc/db.php'; require_once __DIR__ . '/../inc/functions.php';
$categories = getCategories(); $id = $_GET['id'] ?? null; if (!$id) { header('Location: dashboard.php'); exit; }
$art = $pdo->prepare('SELECT * FROM articles WHERE id = ?'); $art->execute([$id]); $article = $art->fetch(); if (!$article) { header('Location: dashboard.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') { $title = trim($_POST['title']); $slug = create_slug($title); $excerpt = $_POST['excerpt'] ?? ''; $content = $_POST['content'] ?? ''; $category_id = $_POST['category_id'] ?: null; $status = $_POST['status'] ?? 'draft'; $publish_at = $_POST['publish_at'] ?: null; $uploaded = handle_upload($_FILES['featured_image'] ?? null); if ($uploaded) { $pdo->prepare('UPDATE articles SET featured_image = ? WHERE id = ?')->execute([$uploaded, $id]); } $pdo->prepare('UPDATE articles SET title=?, slug=?, excerpt=?, content=?, category_id=?, status=?, publish_at=? WHERE id=?')->execute([$title, $slug, $excerpt, $content, $category_id, $status, $publish_at, $id]); header('Location: dashboard.php'); exit; }
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Edit Article</title><link rel="stylesheet" href="/assets/css/styles.css"></head>
<body>
<div class="admin-wrap">
  <h1>Edit Article</h1>
  <form method="post" enctype="multipart/form-data">
    <input name="title" value="<?= e($article['title']) ?>" required>
    <input name="slug" value="<?= e($article['slug']) ?>">
    <select name="category_id"><option value="">Select category</option><?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= $article['category_id']==$c['id']? 'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select>
    <?php if ($article['featured_image']): ?><img src="<?= UPLOAD_WEB . '/' . e($article['featured_image']) ?>" style="max-width:200px;display:block;margin-bottom:10px;" /><?php endif; ?>
    <input name="featured_image" type="file">
    <textarea name="excerpt"><?= e($article['excerpt']) ?></textarea>
    <textarea name="content"><?= e($article['content']) ?></textarea>
    <select name="status"><option value="draft" <?= $article['status']=='draft'?'selected':'' ?>>Draft</option><option value="published" <?= $article['status']=='published'?'selected':'' ?>>Published</option><option value="scheduled" <?= $article['status']=='scheduled'?'selected':'' ?>>Scheduled</option></select>
    <input type="datetime-local" name="publish_at" value="<?= $article['publish_at'] ? date('Y-m-d\TH:i', strtotime($article['publish_at'])) : '' ?>">
    <button>Save</button>
  </form>
</div>
</body></html>