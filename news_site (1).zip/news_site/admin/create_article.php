<?php
require_once __DIR__ . '/../inc/auth.php'; require_login();
require_once __DIR__ . '/../inc/db.php'; require_once __DIR__ . '/../inc/functions.php';
$categories = getCategories();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']); $slug = create_slug($title); $excerpt = $_POST['excerpt'] ?? ''; $content = $_POST['content'] ?? ''; $category_id = $_POST['category_id'] ?: null; $status = $_POST['status'] ?? 'draft'; $publish_at = $_POST['publish_at'] ?: null; $uploaded = handle_upload($_FILES['featured_image'] ?? null);
    $stmt = $pdo->prepare('INSERT INTO articles (title, slug, excerpt, content, author_id, featured_image, category_id, status, publish_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([$title, $slug, $excerpt, $content, $_SESSION['user_id'], $uploaded, $category_id, $status, $publish_at]);
    header('Location: dashboard.php'); exit;
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Create Article</title><link rel="stylesheet" href="/assets/css/styles.css"></head>
<body>
<div class="admin-wrap">
  <h1>Create Article</h1>
  <form method="post" enctype="multipart/form-data">
    <input name="title" placeholder="Title" required>
    <input name="slug" placeholder="Slug (auto)">
    <select name="category_id"><option value="">Select category</option><?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?></select>
    <input name="featured_image" type="file">
    <textarea name="excerpt" placeholder="Excerpt"></textarea>
    <textarea name="content" placeholder="Content HTML"></textarea>
    <select name="status"><option value="draft">Draft</option><option value="published">Publish now</option><option value="scheduled">Schedule</option></select>
    <input type="datetime-local" name="publish_at">
    <button>Create</button>
  </form>
</div>
</body></html>