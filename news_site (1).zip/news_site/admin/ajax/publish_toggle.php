<?php
require_once __DIR__ . '/../../inc/auth.php';
require_once __DIR__ . '/../../inc/db.php';
header('Content-Type: application/json');

session_start();
if (empty($_SESSION['user_id'])) { http_response_code(401); echo json_encode(['error'=>'login']); exit; }
if (!in_array($_SESSION['role'], ['admin','editor'])) { http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$publish = isset($_POST['publish']) ? (int)$_POST['publish'] : 0;
if (!$id) { http_response_code(400); echo json_encode(['error'=>'invalid']); exit; }

$status = $publish ? 'published' : 'draft';
$stmt = $pdo->prepare('UPDATE articles SET status = ? WHERE id = ?');
$stmt->execute([$status, $id]);

echo json_encode(['ok'=>true,'status'=>$status]);