<?php
require_once __DIR__ . '/../../inc/auth.php';
require_once __DIR__ . '/../../inc/db.php';
header('Content-Type: application/json');

session_start();
if (empty($_SESSION['user_id'])) { http_response_code(401); echo json_encode(['error'=>'login']); exit; }
if (!in_array($_SESSION['role'], ['admin','editor'])) { http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }

$action = $_POST['action'] ?? '';
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
if (!$action || !$id) { http_response_code(400); echo json_encode(['error'=>'invalid']); exit; }

if ($action === 'approve') {
    $stmt = $pdo->prepare('UPDATE comments SET status = ? WHERE id = ?');
    $stmt->execute(['approved', $id]);
    echo json_encode(['ok'=>true,'status'=>'approved']); exit;
}
if ($action === 'reject') {
    $stmt = $pdo->prepare('UPDATE comments SET status = ? WHERE id = ?');
    $stmt->execute(['rejected', $id]);
    echo json_encode(['ok'=>true,'status'=>'rejected']); exit;
}
if ($action === 'spam') {
    $stmt = $pdo->prepare('UPDATE comments SET status = ? WHERE id = ?');
    $stmt->execute(['spam', $id]);
    echo json_encode(['ok'=>true,'status'=>'spam']); exit;
}

http_response_code(400); echo json_encode(['error'=>'unknown']);