<?php
require_once __DIR__ . '/../inc/auth.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = $_POST['username'] ?? '';
    $p = $_POST['password'] ?? '';
    if (login($u, $p)) { header('Location: /admin/dashboard.php'); exit; } else { $error = 'Invalid credentials'; }
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Admin Login</title><link rel="stylesheet" href="/assets/css/styles.css"></head>
<body>
<div class="login">
  <h2>Admin Login</h2>
  <?php if (!empty($error)): ?><div class="error"><?= e($error) ?></div><?php endif; ?>
  <form method="post">
    <input name="username" placeholder="Username">
    <input name="password" type="password" placeholder="Password">
    <button>Login</button>
  </form>
</div>
</body></html>