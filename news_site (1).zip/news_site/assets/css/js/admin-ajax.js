async function postJSON(url, data) {
  const res = await fetch(url, { method: 'POST', body: data });
  return res.json();
}

document.addEventListener('click', function(e){
  if (e.target.matches('.comment-action')) {
    e.preventDefault();
    const id = e.target.dataset.id;
    const action = e.target.dataset.action;
    const fd = new FormData(); fd.append('id', id); fd.append('action', action);
    postJSON('/admin/ajax/comment_actions.php', fd).then(r => {
      if (r.ok) { const row = document.querySelector('#comment-'+id); if (row) row.remove(); }
      else alert('Error: ' + (r.error||'unknown'));
    });
  }

  if (e.target.matches('.publish-toggle')) {
    const id = e.target.dataset.id;
    const publish = e.target.checked ? 1 : 0;
    const fd = new FormData(); fd.append('id', id); fd.append('publish', publish);
    postJSON('/admin/ajax/publish_toggle.php', fd).then(r => { if (!r.ok) alert('Toggle failed'); });
  }

  if (e.target.matches('.image-delete')) {
    const name = e.target.dataset.name;
    if (!confirm('Delete ' + name + '?')) return;
    const fd = new FormData(); fd.append('name', name);
    postJSON('/api/image_delete.php', fd).then(r => { if (r.ok) { document.querySelector('#img-'+cssEscape(name)).remove(); } else alert('Del failed'); });
  }
});

function cssEscape(s) { return s.replace(/[^a-z0-9_-]/gi, function(c){ return '\\' + c.charCodeAt(0).toString(16) + ' '; }); }