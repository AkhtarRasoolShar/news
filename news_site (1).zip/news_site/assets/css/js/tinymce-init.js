document.addEventListener('DOMContentLoaded', function(){
  if (!window.tinymce) return;
  tinymce.init({
    selector: 'textarea[name="content"]',
    height: 400,
    plugins: 'image link media table lists code',
    toolbar: 'undo redo | formatselect | bold italic | alignleft aligncenter alignright | bullist numlist | image link | code',
    images_upload_handler: function (blobInfo, success, failure) {
      var formData = new FormData();
      formData.append('file', blobInfo.blob(), blobInfo.filename());
      fetch('/api/image_upload.php', { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => { if (data.url) success(data.url); else failure('Upload failed'); })
        .catch(() => failure('Upload error'));
    }
  });
});