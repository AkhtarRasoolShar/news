<?php
require_once __DIR__ . '/inc/db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    if ($email) {
        $token = bin2hex(random_bytes(32));
        $stmt = $pdo->prepare('INSERT INTO subscribers (email, token) VALUES (?, ?) ON DUPLICATE KEY UPDATE token = VALUES(token), verified = 0');
        $stmt->execute([$email, $token]);
        $link = BASE_URL . '/api/newsletter_subscribe.php?token=' . $token;
        mail($email, 'Confirm subscription', "Click to confirm: $link", 'From: no-reply@example.com');
        $message = 'Please check your email to confirm subscription.';
    } else {
        $message = 'Invalid email.';
    }
}
require_once __DIR__ . '/templates/header.php';
?>
<h2>Subscribe</h2>
<?php if (!empty($message)): ?><div class="notice"><?= e($message) ?></div><?php endif; ?>
<form method="post">
  <input name="email" placeholder="you@example.com">
  <button>Subscribe</button>
</form>
<?php require_once __DIR__ . '/templates/footer.php'; ?>