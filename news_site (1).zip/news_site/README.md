# News Website

Instructions:
1. Import `db.sql` into MySQL.
2. Update `inc/config.php` DB credentials and `BASE_URL`.
3. Ensure `assets/uploads` is writable.
4. Run `php -S localhost:8000 -t .` and visit `http://localhost:8000`.

Default admin: admin / sain12