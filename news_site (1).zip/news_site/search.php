<?php
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/templates/header.php';
$q = trim($_GET['q'] ?? '');
$results = [];
if ($q !== '') {
    $stmt = $pdo->prepare('SELECT title, slug, excerpt FROM articles WHERE status = "published" AND (title LIKE ? OR excerpt LIKE ? OR content LIKE ?) LIMIT 20');
    $like = '%' . $q . '%';
    $stmt->execute([$like,$like,$like]);
    $results = $stmt->fetchAll();
}
?>
<h2>Search results for <?= e($q) ?></h2>
<?php foreach ($results as $r): ?>
  <article>
    <h3><a href="article.php?slug=<?= e($r['slug']) ?>"><?= e($r['title']) ?></a></h3>
    <p><?= e(excerpt($r['excerpt'] ?: $r['title'])) ?></p>
  </article>
<?php endforeach; ?>

<?php require_once __DIR__ . '/templates/footer.php'; ?>