<?php
$rootPath = realpath(__DIR__);
$zipFile = __DIR__ . '/news_website.zip';
$zip = new ZipArchive();
$zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE);
$files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($rootPath), RecursiveIteratorIterator::LEAVES_ONLY);
foreach ($files as $name => $file) {
    if (!$file->isFile()) continue;
    $filePath = $file->getRealPath();
    $relativePath = substr($filePath, strlen($rootPath) + 1);
    if ($relativePath === basename($zipFile)) continue;
    $zip->addFile($filePath, $relativePath);
}
$zip->close();
echo "Created news_website.zip";